<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

include_once WC_ABSPATH.'/includes/wc-order-functions.php';

function wpmelhorenvio_getDocsOrder($order_id) {

    $docs = get_post_meta($order_id, 'wpme_info_order_docs');

    if (!isset($docs[0])) {
        return [
            'key_nf' => '',
            'nf' => '',
            'ie' => '',
            'cnpj' => get_option('wpmelhorenvio_document')
        ];
    }

    return $docs[0];
}