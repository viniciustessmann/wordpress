<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

include_once WC_ABSPATH.'/includes/wc-order-functions.php';

function wpmelhorenvio_getPackageInternal($package){

    // $weight =0;
    // $valor =0;
    // $weightTotal =0;
    $pacote = new stdClass();
    $result = wpmelhorenvio_getProducts($package['line_items']);
    // $products = [];
    // foreach ($package['line_items'] as $item){

    //     $weightProd = wc_get_product($item['product_id'])->get_weight();
    //     if (empty($weightProd) || $weightProd == 0) {
    //         if (!isset($saved_optionals->peso_padrao)) {
    //             $saved_optionals->peso_padrao = 2;
    //         }
    //         $weightProd = $saved_optionals->peso_padrao;
    //     }

    //     $widthProd = wc_get_product($item['product_id'])->get_width();
    //     if (empty($widthProd) || $widthProd == 0) {
    //         if (!isset($saved_optionals->largura_padrao)) {
    //             $saved_optionals->largura_padrao = 17;
    //         }
    //         $widthProd = $saved_optionals->largura_padrao;
    //     }

    //     $heightProd = wc_get_product($item['product_id'])->get_height();
    //     if (empty($heightProd) || $heightProd == 0) {
    //         if (!isset($saved_optionals->altura_padrao)) {
    //             $saved_optionals->altura_padrao = 4;
    //         }
    //         $heightProd = $saved_optionals->altura_padrao;
    //     }

    //     $lengthProd = wc_get_product($item['product_id'])->get_length();
    //     if (empty($lengthProd) || $lengthProd == 0) {
    //         if (!isset($saved_optionals->comprimento_padrao)) {
    //             $saved_optionals->comprimento_padrao = 12;
    //         }
    //         $lengthProd = $saved_optionals->comprimento_padrao;
    //     }

    //     $weightTotal = $weightTotal + $weightProd;

    //     $weight = $weight + $weightProd;
    //     $valor = wc_get_product($item['product_id'])->get_price();

    //     $products[] = [
    //         "id"       => $item['product_id'], 
    //         "weight"   => $weightProd,
    //         "width"    => $widthProd, 
    //         "height"   => $heightProd, 
    //         "length"   => $lengthProd,
    //         "quantity" => $item['quantity'], 
    //         "insurance_value" => wc_get_product($item['product_id'])->get_price()
    //     ];

    // }
    
    $token = get_option('wpmelhorenvio_token');
    $client = new WP_Http();

    $body = [
        "from" => [
            "postal_code" => "96020360",
            'address'     => 'Endereço do remetente',
            'number'      => '1'
        ],
        'to' => [
            'postal_code' => '96065710',
            'address'     => 'Endereço do destinatario',
            'number'      => '2'
        ],
        'products' => $result['products'],
        'options' => [
            "insurance_value" => 0,
            "receipt"         => false, 
            "own_hand"        => false, 
            "collect"         => false 
        ],
        "services" => "1,2" 
    ];

    $params = array(
        'headers'           =>  [
            'Content-Type'  => 'application/json',
            'Accept'        =>  'application/json',
            'Authorization' =>  'Bearer '.$token
        ],
        'sslverify' => getSllVerify(),
        'body'  => json_encode($body),
        'timeout'=>10);

    $response = $client->post('https://www.melhorenvio.com.br/api/v2/me/shipment/calculate',$params);
    $resposta = json_decode($response['body']);

    $pacote->width  = $resposta[0]->packages[0]->dimensions->width >= 12  ? $resposta[0]->packages[0]->dimensions->width : 12;
    $pacote->height = $resposta[0]->packages[0]->dimensions->height >= 4   ? $resposta[0]->packages[0]->dimensions->height : 4;
    $pacote->length = $resposta[0]->packages[0]->dimensions->length >= 17  ? $resposta[0]->packages[0]->dimensions->length : 17;
    $pacote->weight = $weightTotal;
    $pacote->value = $valor;

    return $pacote;
}

function wpmelhorenvio_getCustomerCotacaoAPI($order){

    $quotation = get_post_meta($order['id'], 'quotation_estimate');

    if (!empty($quotation)) {  
        return $quotation[0];
    }
    
    $client = new WP_Http();

    $pacote = wpmelhorenvio_getPackageInternal($order);

    $cep_origin = wpmelhorenvio_getFrom();

    $token = get_option('wpmelhorenvio_token');

    $cep_destination = $order['shipping']['postcode'];

    $opcionais = wpmelhorenvio_getOptionals();

    $seguro = wpmelhorenvio_getValueInsurance($pacote->value,$opcionais->VD);

    $params = array(
        'headers'           =>  ['Content-Type'  => 'application/json',
            'Accept'        =>  'application/json',
            'Authorization' =>  'Bearer '.$token
        ],
        'sslverify' => getSllVerify(),
        'body'  =>[
            'from'      => $cep_origin,
            'to'        => $cep_destination,
            'width'     => $pacote->width,
            'height'    => $pacote->height,
            'length'    => $pacote->length,
            'weight'    => $pacote->weight,
            'services'  => wpmelhorenvio_getSavedServices(),
            'receipt'   => $opcionais->AR,
            'own_hand'  => $opcionais->MP,
            'insurance_value' => $seguro
        ],
        'timeout'=>10);
    
    $response = $client->get("https://www.melhorenvio.com.br/api/v2/calculator",$params);

    add_post_meta($order['id'], 'quotation_estimate', wpmelhorenvio_normalizeData($response['body']));

    return is_array($response) ?  $response['body'] : [];
}