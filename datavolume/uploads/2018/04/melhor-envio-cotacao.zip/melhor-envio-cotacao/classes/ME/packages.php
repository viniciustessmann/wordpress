<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

include_once WC_ABSPATH.'/includes/wc-order-functions.php';


