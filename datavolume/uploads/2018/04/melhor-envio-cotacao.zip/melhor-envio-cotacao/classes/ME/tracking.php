<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

function wpmelhorenvio_data_getTracking($id){
    global $wpdb;
    $sql = $wpdb->prepare("SELECT * FROM {$wpdb->prefix}tracking_codes_wpme where order_id = '%d'",$id);
    return $wpdb->get_results($sql);
}

function wpmelhorenvio_data_getAllTrackings(){
    global $wpdb;
    $sql = "SELECT * FROM {$wpdb->prefix}tracking_codes_wpme limit 3000";
    return $wpdb->get_results($sql);
}

function wpmelhorenvio_data_getAllTrackingsIds(){
    global $wpdb;
    $sql = "SELECT * FROM {$wpdb->prefix}tracking_codes_wpme limit 3000";
    $result =  $wpdb->get_results($sql);

    $ids = [];
    foreach ($result as $item) {
        $ids[] = intval($item->order_id);
    }
    
    return $ids;
}

function wpmelhorenvio_data_insertTracking($id,$tracking,$service){
    global $wpdb;
    $sql = $wpdb->prepare("INSERT INTO {$wpdb->prefix}tracking_codes_wpme (order_id,tracking_id,service_id,status) VALUES ('%d','%s','%s','cart')",$id,$tracking,$service);
    return $wpdb->query($sql);
}

function wpmelhorenvio_data_deleteTracking($tracking){
    global $wpdb;
    return $wpdb->delete($wpdb->prefix.'tracking_codes_wpme' , array('tracking_id' => $tracking));
}

function wpmelhorenvio_data_updateTracking($tracking,$valor){
    global $wpdb;
    $sql = $wpdb->prepare("UPDATE {$wpdb->prefix}tracking_codes_wpme SET status='%s' WHERE tracking_id = '%s'",$valor,$tracking);
    return $wpdb->query($sql);
}