<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

include_once WC_ABSPATH.'/includes/wc-order-functions.php';

function getProductsInCart() {

    global $woocommerce;

    $response  = [];

    $items = $woocommerce->cart->get_cart();

    // $weight =0;
    // $valor =0;
    $pacote = new stdClass();
    // $total = 0;

    // $products = [];
    // foreach($items as $key => $item) { 

    //     $weightProd = wc_get_product($item['product_id'])->get_weight();
    //     if (empty($weightProd) || $weightProd == 0) {
    //         if (!isset($saved_optionals->peso_padrao)) {
    //             $saved_optionals->peso_padrao = 2;
    //         }
    //         $weightProd = $saved_optionals->peso_padrao;
    //     }

    //     $widthProd = wc_get_product($item['product_id'])->get_width();
    //     if (empty($widthProd) || $widthProd == 0) {
    //         if (!isset($saved_optionals->largura_padrao)) {
    //             $saved_optionals->largura_padrao = 17;
    //         }
    //         $widthProd = $saved_optionals->largura_padrao;
    //     }

    //     $heightProd = wc_get_product($item['product_id'])->get_height();
    //     if (empty($heightProd) || $heightProd == 0) {
    //         if (!isset($saved_optionals->altura_padrao)) {
    //             $saved_optionals->altura_padrao = 4;
    //         }
    //         $heightProd = $saved_optionals->altura_padrao;
    //     }

    //     $lengthProd = wc_get_product($item['product_id'])->get_length();
    //     if (empty($lengthProd) || $lengthProd == 0) {
    //         if (!isset($saved_optionals->comprimento_padrao)) {
    //             $saved_optionals->comprimento_padrao = 12;
    //         }
    //         $lengthProd = $saved_optionals->comprimento_padrao;
    //     }


    //     $weight = $weightProd;
    //     $valor = floatval(wc_get_product($item['product_id'])->get_price());

    //     $total = $total + $valor;

    //     $products[] = [
    //         "id"       => $item['product_id'], 
    //         "weight"   => $weightProd, 
    //         "width"    => $widthProd, 
    //         "height"   => $heightProd, 
    //         "length"   => $lengthProd,
    //         "quantity" => $item['quantity'], 
    //         "insurance_value" => wc_get_product($item['product_id'])->get_price()
    //     ];
    // } 

    // return  [
    //     'products' => $products,
    //     'weight'   => $weight,
    //     'valor'    => $total
    // ];

    return wpmelhorenvio_getProducts($items);
}