# Melhor Envio - Cotação
Contributors: Vítor Soares.

Requires at least: 4.0.

Tested up to: 4.8.

Stable tag: 1.0.6

License: GPLv2 or later.

License URI: http://www.gnu.org/licenses/gpl-2.0.html.

Text Domain: MelhorEnvio.

Tags: Woocommerce, Shipping, Delivery, Melhor envio, Envios, Correios, Transportadoras, Frete

Integration between the Melhor Envio and WooCommerce.

## Description
O plugin da Melhor Envio para o Woocommerce permite que você cote através de diversas transportadoras utilizando a API e os contratos do Melhor Envio.

O que é a Melhor Envio?

https://www.youtube.com/embed/is-RqEIYDRA

O Melhor Envio torna o processo de envio mais simples e barato.

## Installation
Baixe o plugin pelo site do Melhor Envio na sessão de integrações (http://www.melhorenvio.com.br/integracoes/) ou pela página do plugin na loja do Wordpress. Após o download vá ao seu painel de administrador do Wordpress. Clique em Plugins > Add New >.

 Na página seguinte, você deverá clicar em Upload Plugin, Nessa página você poderá subir o arquivo do pacote do Melhor Envio. Escolha o arquivo baixado e clique em Install Now, o plugin será instalado completamente e caberá a você apenas configurá-lo.

descrição da instalação

## Compatibilidade

Compatível com a versão 3.0.x do WooCommerce.

## Perguntas Frequentes
Os preços entregues pela plataforma são os preços de Balcão? Não, os preços entregues pela plataforma são os preços disponibilizados pela nossa API baseado no nosso contrato com os correios.

### O que eu preciso fazer para habilitar a minha conta?
Para habilitar a sua conta é necessário se cadastrar no site do Melhor Envio, dessa forma você tem acesso ao nosso painel de controle e pode gerenciar de la todos os seus envios.

## Upgrade Notice

1.2 Nesta nova versão temos uma super novidade.

## Screenshots

1. Aqui é a descrição da primeira screenshot. A imagem vai na raiz do plugin seu nome deve ser screenshot-1, screenshot-2 e etc..

2. Aqui vem a descrição da segunda screenshot

