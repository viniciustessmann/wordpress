<?php

function wpmelhorenviopackage_getPackageInternal($package = [], $service, $ar = false, $mp = false){

    if (!isset($package['destination']['postcode']) || empty($package['destination']['postcode'])) {
        return null;
    }

    global $woocommerce;
    $items = $woocommerce->cart->get_cart();

    $pacote = new stdClass();

    $token = get_option('wpmelhorenvio_token');
    $client = new WP_Http();
    $result = wpmelhorenvio_getProducts($items);

    $address = str_replace("\\" ,"", get_option('wpmelhorenvio_address'));
    
    $body = [
        "from" => [
            "postal_code" => json_decode($address)->postal_code
        ],
        'to' => [
            'postal_code' => $package['destination']['postcode']
        ],
        'products' => $result['products'],
        'options' => [
            "insurance_value" => $result['valor_total'],
            "receipt"         => $ar, 
            "own_hand"        => $mp, 
            "collect"         => false 
        ],
        "services" => $service 
    ];

    $params = array(
        'headers'           =>  [
            'Content-Type'  => 'application/json',
            'Accept'        =>  'application/json',
            'Authorization' =>  'Bearer '.$token
        ],
        'sslverify' => getSllVerify(),
        'body'  => json_encode($body),
        'timeout'=>10);

    $response = $client->post('https://www.melhorenvio.com.br/api/v2/me/shipment/calculate',$params);

    if (!is_wp_error($response)) {
        if ($response['response']['code'] == 200) {
            $resposta = json_decode($response['body']);
            if($resposta->error) {
                insertLogErrorMelhorEnvio($resposta);
                return null;
            }
            return $resposta;
        }
    }

    return null;
}
